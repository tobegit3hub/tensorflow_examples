import setuptools

NAME = 'trainer'
VERSION = '1.0'

if __name__ == '__main__':
    setuptools.setup(name=NAME, version=VERSION, packages=['trainer'])
